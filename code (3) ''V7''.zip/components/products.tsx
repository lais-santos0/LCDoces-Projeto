"use client"

import { useState } from "react"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Star, TrendingUp, Award, Sparkles } from "lucide-react"

const products = {
  destaques: [
    {
      name: "Brigadeiro Gourmet",
      description: "Brigadeiro cremoso com chocolate belga e granulado especial",
      price: "R$ 3,50",
      image: "/gourmet-chocolate-brigadeiro.jpg",
    },
    {
      name: "Brownie Recheado",
      description: "Brownie artesanal com recheio de doce de leite",
      price: "R$ 8,00",
      image: "/chocolate-brownie-with-dulce-de-leche.jpg",
    },
    {
      name: "Torta de Limão",
      description: "Torta cremosa com massa crocante e merengue suíço",
      price: "R$ 45,00",
      image: "/lemon-meringue-pie.jpg",
    },
  ],
  maisPedidos: [
    {
      name: "Beijinho Tradicional",
      description: "Beijinho clássico com coco ralado fresco",
      price: "R$ 3,00",
      image: "/coconut-beijinho-brazilian-sweet.jpg",
    },
    {
      name: "Brigadeiro Tradicional",
      description: "O clássico que todo mundo ama",
      price: "R$ 2,50",
      image: "/traditional-brigadeiro.jpg",
    },
    {
      name: "Cajuzinho",
      description: "Doce de amendoim em formato de caju",
      price: "R$ 3,00",
      image: "/cajuzinho-brazilian-peanut-candy.jpg",
    },
  ],
  classicos: [
    {
      name: "Olho de Sogra",
      description: "Ameixa recheada com doce de coco",
      price: "R$ 3,50",
      image: "/stuffed-prune-with-coconut.jpg",
    },
    {
      name: "Quindim",
      description: "Doce tradicional de coco e gemas",
      price: "R$ 4,00",
      image: "/quindim-brazilian-coconut-dessert.jpg",
    },
    {
      name: "Cocada Branca",
      description: "Cocada cremosa feita no ponto certo",
      price: "R$ 3,00",
      image: "/white-coconut-cocada.jpg",
    },
  ],
  gourmet: [
    {
      name: "Brigadeiro de Pistache",
      description: "Brigadeiro sofisticado com pistache importado",
      price: "R$ 5,00",
      image: "/pistachio-brigadeiro.jpg",
    },
    {
      name: "Trufa de Maracujá",
      description: "Trufa de chocolate branco com ganache de maracujá",
      price: "R$ 4,50",
      image: "/passion-fruit-white-chocolate-truffle.jpg",
    },
    {
      name: "Brownie Red Velvet",
      description: "Brownie aveludado com cream cheese",
      price: "R$ 10,00",
      image: "/red-velvet-brownie-cream-cheese.jpg",
    },
  ],
}

const tabConfig = [
  { value: "destaques", label: "Destaques", icon: Star },
  { value: "maisPedidos", label: "Mais Pedidos", icon: TrendingUp },
  { value: "classicos", label: "Clássicos", icon: Award },
  { value: "gourmet", label: "Gourmet", icon: Sparkles },
]

export function Products() {
  const [activeTab, setActiveTab] = useState("destaques")

  return (
    <section id="produtos" className="py-20 bg-gradient-to-b from-background to-[#b3fffd]/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">Nossos Produtos</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
            Explore nossa seleção de doces artesanais, feitos com ingredientes de qualidade e muito carinho
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto gap-2 bg-muted/50 p-2">
            {tabConfig.map(({ value, label, icon: Icon }) => (
              <TabsTrigger
                key={value}
                value={value}
                className="flex items-center gap-2 text-base py-3 data-[state=active]:bg-[#e7adff] data-[state=active]:text-foreground"
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                <span className="hidden sm:inline">{label}</span>
                <span className="sm:hidden">{label.split(" ")[0]}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {Object.entries(products).map(([key, items]) => (
            <TabsContent key={key} value={key} className="mt-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {items.map((product, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow bg-card border-2">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-48 object-cover"
                    />
                    <CardHeader>
                      <div className="flex items-start justify-between gap-2">
                        <CardTitle className="text-xl text-balance">{product.name}</CardTitle>
                        <Badge className="bg-[#feffcb] text-foreground hover:bg-[#feffcb]/80 font-semibold">
                          {product.price}
                        </Badge>
                      </div>
                      <CardDescription className="text-base leading-relaxed">{product.description}</CardDescription>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}
