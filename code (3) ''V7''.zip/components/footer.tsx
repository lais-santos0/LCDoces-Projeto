import { Heart } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-[#e7adff]/20 border-t py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center gap-4 text-center">
          <p className="text-lg font-bold text-foreground">LC Doces caseiros</p>
          <p className="text-base text-muted-foreground flex items-center gap-2 text-pretty">
            Feito com <Heart className="h-4 w-4 text-red-500 fill-red-500" aria-label="amor" /> e muito carinho
          </p>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} LC Doces caseiros. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
