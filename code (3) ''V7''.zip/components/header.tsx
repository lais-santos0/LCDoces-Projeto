"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setIsMenuOpen(false)
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-[#feffcb]/95 backdrop-blur supports-[backdrop-filter]:bg-[#feffcb]/80">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <button
          onClick={() => scrollToSection("hero")}
          className="text-2xl font-bold text-foreground hover:opacity-80 transition-opacity"
          aria-label="LC Doces caseiros - Ir para início"
        >
          <span className="text-balance">LC Doces caseiros</span>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6" aria-label="Navegação principal">
          <button
            onClick={() => scrollToSection("produtos")}
            className="text-base font-medium text-foreground hover:text-primary transition-colors"
          >
            Produtos
          </button>
          <button
            onClick={() => scrollToSection("sobre")}
            className="text-base font-medium text-foreground hover:text-primary transition-colors"
          >
            Quem Somos
          </button>
          <button
            onClick={() => scrollToSection("contato")}
            className="text-base font-medium text-foreground hover:text-primary transition-colors"
          >
            Contato
          </button>
        </nav>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
          aria-expanded={isMenuOpen}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <nav className="md:hidden border-t bg-[#feffcb]" aria-label="Menu mobile">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <button
              onClick={() => scrollToSection("produtos")}
              className="text-lg font-medium text-foreground hover:text-primary transition-colors text-left"
            >
              Produtos
            </button>
            <button
              onClick={() => scrollToSection("sobre")}
              className="text-lg font-medium text-foreground hover:text-primary transition-colors text-left"
            >
              Quem Somos
            </button>
            <button
              onClick={() => scrollToSection("contato")}
              className="text-lg font-medium text-foreground hover:text-primary transition-colors text-left"
            >
              Contato
            </button>
          </div>
        </nav>
      )}
    </header>
  )
}
