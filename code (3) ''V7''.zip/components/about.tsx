import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Heart, Users } from "lucide-react"

export function About() {
  return (
    <section id="sobre" className="py-20 bg-gradient-to-b from-[#b3fffd]/10 to-[#e7adff]/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">Conheça a LC Doces</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
            Uma história de amor, dedicação e sabores inesquecíveis
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <Card className="border-2 bg-card hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="p-4 bg-[#e7adff]/20 rounded-full">
                  <Heart className="h-8 w-8 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Quem Somos</h3>
                <p className="text-base text-muted-foreground leading-relaxed">
                  Somos uma doceria artesanal familiar que nasceu do amor pela confeitaria. Cada doce é preparado com
                  receitas tradicionais e um toque especial de carinho.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 bg-card hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="p-4 bg-[#b3fffd]/20 rounded-full">
                  <MapPin className="h-8 w-8 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Onde Estamos</h3>
                <p className="text-base text-muted-foreground leading-relaxed">
                  Localizada no coração da cidade, nossa doceria atende toda a região com entregas rápidas e produtos
                  sempre fresquinhos.
                </p>
                <address className="text-base font-medium text-foreground not-italic">
                  Rua das Flores, 123
                  <br />
                  Centro - São Paulo, SP
                </address>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 bg-card hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="p-4 bg-[#feffcb]/20 rounded-full">
                  <Users className="h-8 w-8 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Nossa Missão</h3>
                <p className="text-base text-muted-foreground leading-relaxed">
                  Levar alegria e sabor para cada cliente, criando momentos especiais através de doces artesanais de
                  alta qualidade e atendimento personalizado.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
