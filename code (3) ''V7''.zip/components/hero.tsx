"use client"

import { Button } from "@/components/ui/button"
import { Cake, Heart, Sparkles } from "lucide-react"

export function Hero() {
  const scrollToProducts = () => {
    const element = document.getElementById("produtos")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section
      id="hero"
      className="relative overflow-hidden bg-gradient-to-br from-[#b3fffd] via-[#e7adff] to-[#feffcb] py-20 md:py-32"
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center gap-8">
          <div className="flex items-center gap-3 text-foreground/80">
            <Sparkles className="h-8 w-8" aria-hidden="true" />
            <Cake className="h-10 w-10" aria-hidden="true" />
            <Heart className="h-8 w-8" aria-hidden="true" />
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground text-balance leading-tight">
            Doces Artesanais Feitos com Amor
          </h1>

          <p className="text-lg md:text-xl text-foreground/90 max-w-2xl text-pretty leading-relaxed">
            Sabores únicos e irresistíveis que transformam momentos especiais em memórias doces. Cada doce é preparado
            com carinho e ingredientes selecionados.
          </p>

          <Button
            size="lg"
            onClick={scrollToProducts}
            className="bg-[#e7adff] hover:bg-[#d89fff] text-foreground text-lg px-8 py-6 h-auto font-semibold"
          >
            Conheça Nossos Doces
          </Button>
        </div>
      </div>

      {/* Decorative elements */}
      <div
        className="absolute top-10 left-10 w-20 h-20 bg-[#feffcb] rounded-full opacity-50 blur-xl"
        aria-hidden="true"
      />
      <div
        className="absolute bottom-10 right-10 w-32 h-32 bg-[#b3fffd] rounded-full opacity-50 blur-xl"
        aria-hidden="true"
      />
    </section>
  )
}
