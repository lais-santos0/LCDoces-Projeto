"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Phone, Mail, Instagram, MessageCircle } from "lucide-react"

export function Contact() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    alert("Mensagem enviada! Entraremos em contato em breve.")
  }

  return (
    <section id="contato" className="py-20 bg-gradient-to-b from-[#e7adff]/10 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">Entre em Contato</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
            Estamos prontos para adoçar seu dia! Fale conosco para encomendas e informações
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Contact Information */}
          <div className="space-y-6">
            <Card className="border-2 bg-[#feffcb]/30">
              <CardHeader>
                <CardTitle className="text-2xl">Fale Conosco</CardTitle>
                <CardDescription className="text-base">Escolha a melhor forma de entrar em contato</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <a
                  href="tel:+5511999999999"
                  className="flex items-center gap-4 p-4 bg-card rounded-lg hover:shadow-md transition-shadow border"
                >
                  <div className="p-3 bg-[#b3fffd] rounded-full">
                    <Phone className="h-5 w-5 text-foreground" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-base">Telefone</p>
                    <p className="text-muted-foreground">(11) 99999-9999</p>
                  </div>
                </a>

                <a
                  href="mailto:contato@lcdoces.com.br"
                  className="flex items-center gap-4 p-4 bg-card rounded-lg hover:shadow-md transition-shadow border"
                >
                  <div className="p-3 bg-[#e7adff] rounded-full">
                    <Mail className="h-5 w-5 text-foreground" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-base">E-mail</p>
                    <p className="text-muted-foreground">contato@lcdoces.com.br</p>
                  </div>
                </a>

                <a
                  href="https://wa.me/5511999999999"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 bg-card rounded-lg hover:shadow-md transition-shadow border"
                >
                  <div className="p-3 bg-[#feffcb] rounded-full">
                    <MessageCircle className="h-5 w-5 text-foreground" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-base">WhatsApp</p>
                    <p className="text-muted-foreground">Clique para conversar</p>
                  </div>
                </a>

                <a
                  href="https://instagram.com/lcdocescaseiros"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 bg-card rounded-lg hover:shadow-md transition-shadow border"
                >
                  <div className="p-3 bg-[#b3fffd] rounded-full">
                    <Instagram className="h-5 w-5 text-foreground" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-base">Instagram</p>
                    <p className="text-muted-foreground">@lcdocescaseiros</p>
                  </div>
                </a>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-2xl">Envie uma Mensagem</CardTitle>
              <CardDescription className="text-base">Preencha o formulário e responderemos em breve</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-base font-medium">
                    Nome completo
                  </Label>
                  <Input id="name" placeholder="Seu nome" required className="text-base" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base font-medium">
                    E-mail
                  </Label>
                  <Input id="email" type="email" placeholder="seu@email.com" required className="text-base" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-base font-medium">
                    Telefone
                  </Label>
                  <Input id="phone" type="tel" placeholder="(11) 99999-9999" className="text-base" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message" className="text-base font-medium">
                    Mensagem
                  </Label>
                  <Textarea
                    id="message"
                    placeholder="Conte-nos sobre seu pedido ou dúvida..."
                    required
                    className="min-h-32 text-base resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[#e7adff] hover:bg-[#d89fff] text-foreground text-base font-semibold py-6"
                >
                  Enviar Mensagem
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
