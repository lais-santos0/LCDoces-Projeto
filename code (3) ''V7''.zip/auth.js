// Sistema de autenticação usando localStorage

// Usuário admin padrão
const DEFAULT_ADMIN = {
  email: "admin@lcdoces.com",
  password: "admin123",
  name: "Administrador",
  role: "admin",
}

// Tipo de usuário atual (cliente ou admin)
let currentUserType = "cliente"

// Alternar entre abas de login
function switchTab(type) {
  currentUserType = type
  const tabs = document.querySelectorAll(".login-tab")
  tabs.forEach((tab) => tab.classList.remove("active"))
  event.target.classList.add("active")
}

// Função de login
function handleLogin(event) {
  event.preventDefault()

  const email = document.getElementById("email").value
  const password = document.getElementById("password").value
  const remember = document.getElementById("remember")?.checked

  // Verificar se é admin
  if (currentUserType === "admin") {
    if (email === DEFAULT_ADMIN.email && password === DEFAULT_ADMIN.password) {
      const adminData = {
        ...DEFAULT_ADMIN,
        loginTime: new Date().toISOString(),
      }

      if (remember) {
        localStorage.setItem("currentUser", JSON.stringify(adminData))
      } else {
        sessionStorage.setItem("currentUser", JSON.stringify(adminData))
      }

      window.location.href = "admin-dashboard.html"
      return
    } else {
      alert("Credenciais de administrador inválidas!")
      return
    }
  }

  // Login de cliente
  const users = JSON.parse(localStorage.getItem("users") || "[]")
  const user = users.find((u) => u.email === email && u.password === password)

  if (user) {
    const userData = {
      ...user,
      loginTime: new Date().toISOString(),
    }

    if (remember) {
      localStorage.setItem("currentUser", JSON.stringify(userData))
    } else {
      sessionStorage.setItem("currentUser", JSON.stringify(userData))
    }

    window.location.href = "cliente-dashboard.html"
  } else {
    alert("E-mail ou senha incorretos!")
  }
}

// Função de registro
function handleRegister(event) {
  event.preventDefault()

  const name = document.getElementById("name").value
  const email = document.getElementById("email").value
  const phone = document.getElementById("phone").value
  const address = document.getElementById("address").value
  const password = document.getElementById("password").value
  const confirmPassword = document.getElementById("confirm-password").value

  if (password !== confirmPassword) {
    alert("As senhas não coincidem!")
    return
  }

  // Verificar se o e-mail já existe
  const users = JSON.parse(localStorage.getItem("users") || "[]")
  if (users.find((u) => u.email === email)) {
    alert("Este e-mail já está cadastrado!")
    return
  }

  // Criar novo usuário
  const newUser = {
    id: Date.now(),
    name,
    email,
    phone,
    address,
    password,
    role: "cliente",
    createdAt: new Date().toISOString(),
    orders: [],
  }

  users.push(newUser)
  localStorage.setItem("users", JSON.stringify(users))

  alert("Conta criada com sucesso! Faça login para continuar.")
  window.location.href = "login.html"
}

// Verificar autenticação
function checkAuth(requiredRole = null) {
  const user = getCurrentUser()

  if (!user) {
    window.location.href = "login.html"
    return null
  }

  if (requiredRole && user.role !== requiredRole) {
    alert("Acesso não autorizado!")
    window.location.href = "login.html"
    return null
  }

  return user
}

// Obter usuário atual
function getCurrentUser() {
  const userStr = localStorage.getItem("currentUser") || sessionStorage.getItem("currentUser")
  return userStr ? JSON.parse(userStr) : null
}

// Logout
function logout() {
  if (confirm("Deseja realmente sair?")) {
    localStorage.removeItem("currentUser")
    sessionStorage.removeItem("currentUser")
    window.location.href = "index.html"
  }
}

// Atualizar perfil
function updateProfile(event) {
  event.preventDefault()

  const user = getCurrentUser()
  if (!user) return

  const name = document.getElementById("profile-name").value
  const email = document.getElementById("profile-email").value
  const phone = document.getElementById("profile-phone").value
  const address = document.getElementById("profile-address").value

  // Atualizar dados do usuário
  const users = JSON.parse(localStorage.getItem("users") || "[]")
  const userIndex = users.findIndex((u) => u.id === user.id)

  if (userIndex !== -1) {
    users[userIndex] = {
      ...users[userIndex],
      name,
      email,
      phone,
      address,
    }

    localStorage.setItem("users", JSON.stringify(users))

    // Atualizar sessão atual
    const updatedUser = users[userIndex]
    if (localStorage.getItem("currentUser")) {
      localStorage.setItem("currentUser", JSON.stringify(updatedUser))
    } else {
      sessionStorage.setItem("currentUser", JSON.stringify(updatedUser))
    }

    alert("Perfil atualizado com sucesso!")
    location.reload()
  }
}
