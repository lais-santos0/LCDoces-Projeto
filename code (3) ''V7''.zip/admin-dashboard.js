// Dashboard do administrador

function checkAuth(role) {
  // Placeholder implementation for checkAuth
  return true // Assume user is authenticated for now
}

document.addEventListener("DOMContentLoaded", () => {
  const user = checkAuth("admin")
  if (!user) return

  // Carregar estatísticas
  loadStats()

  // Carregar pedidos
  loadAllOrders()

  // Carregar clientes
  loadCustomers()
})

function loadStats() {
  const users = JSON.parse(localStorage.getItem("users") || "[]")
  const allOrders = users.flatMap((u) => u.orders || [])

  // Total de pedidos hoje
  const today = new Date().toDateString()
  const todayOrders = allOrders.filter((o) => new Date(o.date).toDateString() === today)
  document.getElementById("total-orders").textContent = todayOrders.length

  // Faturamento total
  const totalRevenue = allOrders.reduce((sum, order) => sum + order.total, 0)
  document.getElementById("total-revenue").textContent = `R$ ${totalRevenue.toFixed(2)}`

  // Total de clientes
  document.getElementById("total-customers").textContent = users.length
}

function loadAllOrders() {
  const ordersList = document.getElementById("admin-orders-list")
  const users = JSON.parse(localStorage.getItem("users") || "[]")
  const allOrders = []

  users.forEach((user) => {
    if (user.orders) {
      user.orders.forEach((order) => {
        allOrders.push({
          ...order,
          customerName: user.name,
          customerEmail: user.email,
        })
      })
    }
  })

  if (allOrders.length === 0) {
    ordersList.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📦</div>
                <p>Nenhum pedido registrado ainda</p>
            </div>
        `
    return
  }

  // Ordenar por data (mais recente primeiro)
  allOrders.sort((a, b) => new Date(b.date) - new Date(a.date))

  ordersList.innerHTML = allOrders
    .map(
      (order) => `
        <div class="order-card">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 16px;">
                <div>
                    <h3 style="font-family: var(--font-heading); font-size: 18px; margin-bottom: 4px;">
                        Pedido #${order.id}
                    </h3>
                    <p style="color: var(--text-secondary); font-size: 14px;">
                        Cliente: ${order.customerName} (${order.customerEmail})
                    </p>
                    <p style="color: var(--text-secondary); font-size: 14px;">
                        Data: ${new Date(order.date).toLocaleString("pt-BR")}
                    </p>
                </div>
                <span style="padding: 6px 12px; background-color: var(--candy-yellow); border-radius: 12px; font-size: 12px; font-weight: 600;">
                    ${order.status}
                </span>
            </div>
            <div style="border-top: 1px solid #e0e0e0; padding-top: 16px;">
                ${order.items
                  .map(
                    (item) => `
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span>${item.quantity}x ${item.name}</span>
                        <span style="font-weight: 600;">R$ ${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `,
                  )
                  .join("")}
                <div style="display: flex; justify-content: space-between; margin-top: 16px; padding-top: 16px; border-top: 1px solid #e0e0e0; font-weight: 700; font-size: 18px;">
                    <span>Total:</span>
                    <span style="color: var(--candy-purple);">R$ ${order.total.toFixed(2)}</span>
                </div>
            </div>
        </div>
    `,
    )
    .join("")
}

function loadCustomers() {
  const customersList = document.getElementById("customers-list")
  const users = JSON.parse(localStorage.getItem("users") || "[]")

  if (users.length === 0) {
    customersList.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">👥</div>
                <p>Nenhum cliente cadastrado ainda</p>
            </div>
        `
    return
  }

  customersList.innerHTML = users
    .map(
      (user) => `
        <div class="customer-card">
            <h3 style="font-family: var(--font-heading); font-size: 18px; margin-bottom: 8px;">
                ${user.name}
            </h3>
            <p style="color: var(--text-secondary); font-size: 14px; margin-bottom: 4px;">
                📧 ${user.email}
            </p>
            <p style="color: var(--text-secondary); font-size: 14px; margin-bottom: 4px;">
                📱 ${user.phone}
            </p>
            <p style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">
                📍 ${user.address}
            </p>
            <p style="color: var(--text-light); font-size: 12px;">
                Cadastrado em: ${new Date(user.createdAt).toLocaleDateString("pt-BR")}
            </p>
            <p style="font-weight: 600; margin-top: 8px;">
                Total de pedidos: ${user.orders?.length || 0}
            </p>
        </div>
    `,
    )
    .join("")
}

function showAdminSection(sectionName) {
  // Remover active de todos os nav-items
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
  })

  // Adicionar active ao item clicado
  event.target.classList.add("active")

  // Esconder todas as seções
  document.querySelectorAll(".dashboard-section").forEach((section) => {
    section.style.display = "none"
  })

  // Mostrar seção selecionada
  document.getElementById(`${sectionName}-admin-section`).style.display = "block"
}
