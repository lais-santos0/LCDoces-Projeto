# 🍰 LC Doces Caseiros - Website

Bem-vindo ao site da **LC Doces Caseiros**! Este é um site simples e funcional desenvolvido em HTML, CSS e JavaScript puro.

## 📋 Informações do Negócio

- **Nome**: LC Doces Caseiros
- **Endereço**: Avenida São Judas Tadeu, 905 - João Pessoa/PB
- **WhatsApp**: (83) 98806-6233
- **E-mail**: lcdocescaseiros2020@gmail.com
- **Instagram**: [@l_cdocescaseiros](https://www.instagram.com/l_cdocescaseiros?igsh=MXRuZDhrd280Mnc3bA==)

## 🚀 Como Usar

### Opção 1: Abrir Diretamente no Navegador
1. Localize o arquivo `index.html` na pasta do projeto
2. Clique duas vezes no arquivo para abrir no seu navegador padrão
3. Pronto! O site estará funcionando

### Opção 2: Usar o Live Server no VSCode (Recomendado)
1. Abra o VSCode
2. Instale a extensão "Live Server" (se ainda não tiver)
3. Abra a pasta do projeto no VSCode
4. Clique com o botão direito no arquivo `index.html`
5. Selecione "Open with Live Server"
6. O site abrirá automaticamente no navegador com atualização automática

## 🛒 Funcionalidades

### Carrinho de Compras
- Adicione produtos ao carrinho clicando no ícone 🛒
- Ajuste quantidades diretamente no carrinho
- Remova itens indesejados
- Visualize o total do pedido em tempo real

### Finalizar Pedido
- Ao clicar em "Finalizar Pedido", o sistema:
  1. Monta automaticamente a mensagem com todos os itens
  2. Abre o WhatsApp com a mensagem pronta
  3. Envia o pedido diretamente para (83) 98806-6233
  4. O cliente completa as informações de entrega na conversa

### Categorias de Produtos
- **Destaques**: Trufas e docinhos especiais
- **Mais Pedidos**: Brigadeiros, beijinhos e doces populares
- **Clássicos**: Bolos de pote tradicionais
- **Gourmet**: Pacotes para festas (100 unidades)

## 📝 Como Personalizar

### Adicionar Novos Produtos
1. Abra o arquivo `script.js`
2. Localize o objeto `productsData`
3. Adicione um novo produto seguindo o formato:

\`\`\`javascript
{
  id: 16, // Número único
  name: "Nome do Produto",
  description: "Descrição detalhada",
  price: 10.00, // Preço em reais
  unit: "unidade", // ou "pacote"
  image: "url-da-imagem.jpg",
  category: "categoria"
}
\`\`\`

### Alterar Cores
1. Abra o arquivo `styles.css`
2. No início do arquivo, encontre as variáveis CSS:
\`\`\`css
:root {
  --candy-blue: #b3fffd;
  --candy-purple: #e7adff;
  --candy-yellow: #feffcb;
}
\`\`\`
3. Altere os valores das cores conforme desejado

### Atualizar Informações de Contato
1. Abra o arquivo `index.html`
2. Procure pela seção "Contato" (use Ctrl+F)
3. Atualize telefone, e-mail e endereço
4. Não esqueça de atualizar também os links do WhatsApp e Instagram

### Trocar a Logo
1. Substitua a URL da logo no arquivo `index.html`
2. Procure por `<img src="..." class="logo-image">`
3. Substitua a URL pela nova imagem da logo

## 📱 Responsividade

O site é totalmente responsivo e funciona perfeitamente em:
- 💻 Computadores
- 📱 Celulares
- 📱 Tablets

## 🎨 Estrutura de Arquivos

\`\`\`
lc-doces-caseiros/
│
├── index.html          # Página principal
├── styles.css          # Estilos e cores
├── script.js           # Funcionalidades e produtos
├── LEIA-ME.md         # Este arquivo
└── public/            # Pasta de imagens (opcional)
\`\`\`

## 💡 Dicas

- **Backup**: Sempre faça backup dos arquivos antes de fazer alterações
- **Teste**: Após fazer mudanças, teste o site em diferentes dispositivos
- **Imagens**: Use imagens otimizadas (não muito grandes) para carregar mais rápido
- **Preços**: Mantenha os preços atualizados no arquivo `script.js`

## 🆘 Suporte

Se precisar de ajuda:
1. Verifique se todos os arquivos estão na mesma pasta
2. Certifique-se de que o navegador está atualizado
3. Limpe o cache do navegador (Ctrl+Shift+Delete)
4. Tente abrir em modo anônimo para testar

## 📄 Licença

Este site foi desenvolvido exclusivamente para a LC Doces Caseiros.

---

**Desenvolvido com 💜 para LC Doces Caseiros**

*Última atualização: Novembro 2025*
