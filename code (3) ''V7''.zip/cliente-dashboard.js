// Dashboard do cliente

function checkAuth(role) {
  // Placeholder for authentication check logic
  return { name: "John Doe", email: "john@example.com", phone: "123-456-7890", address: "123 Main St", orders: [] }
}

document.addEventListener("DOMContentLoaded", () => {
  const user = checkAuth("cliente")
  if (!user) return

  // Exibir nome do usuário
  document.getElementById("user-name").textContent = user.name

  // Carregar pedidos do usuário
  loadUserOrders(user)

  // Preencher formulário de perfil
  loadUserProfile(user)
})

function loadUserOrders(user) {
  const ordersList = document.getElementById("orders-list")
  const orders = user.orders || []

  if (orders.length === 0) {
    ordersList.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📦</div>
                <p>Você ainda não fez nenhum pedido</p>
                <a href="index.html" class="btn-primary">Fazer Primeiro Pedido</a>
            </div>
        `
    return
  }

  ordersList.innerHTML = orders
    .map(
      (order) => `
        <div class="order-card">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 16px;">
                <div>
                    <h3 style="font-family: var(--font-heading); font-size: 18px; margin-bottom: 4px;">
                        Pedido #${order.id}
                    </h3>
                    <p style="color: var(--text-secondary); font-size: 14px;">
                        ${new Date(order.date).toLocaleDateString("pt-BR")}
                    </p>
                </div>
                <span style="padding: 6px 12px; background-color: var(--candy-yellow); border-radius: 12px; font-size: 12px; font-weight: 600;">
                    ${order.status}
                </span>
            </div>
            <div style="border-top: 1px solid #e0e0e0; padding-top: 16px;">
                ${order.items
                  .map(
                    (item) => `
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span>${item.quantity}x ${item.name}</span>
                        <span style="font-weight: 600;">R$ ${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `,
                  )
                  .join("")}
                <div style="display: flex; justify-content: space-between; margin-top: 16px; padding-top: 16px; border-top: 1px solid #e0e0e0; font-weight: 700; font-size: 18px;">
                    <span>Total:</span>
                    <span style="color: var(--candy-purple);">R$ ${order.total.toFixed(2)}</span>
                </div>
            </div>
        </div>
    `,
    )
    .join("")
}

function loadUserProfile(user) {
  document.getElementById("profile-name").value = user.name || ""
  document.getElementById("profile-email").value = user.email || ""
  document.getElementById("profile-phone").value = user.phone || ""
  document.getElementById("profile-address").value = user.address || ""
}

function showSection(sectionName) {
  // Remover active de todos os nav-items
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
  })

  // Adicionar active ao item clicado
  event.target.classList.add("active")

  // Esconder todas as seções
  document.querySelectorAll(".dashboard-section").forEach((section) => {
    section.style.display = "none"
  })

  // Mostrar seção selecionada
  document.getElementById(`${sectionName}-section`).style.display = "block"
}
